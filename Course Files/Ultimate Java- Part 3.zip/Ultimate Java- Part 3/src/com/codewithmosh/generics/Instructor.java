package com.codewithmosh.generics;

public class Instructor extends User {
  public Instructor(int points) {
    super(points);
  }
}
